#include <cstdio>
#include <algorithm>
#include <opencv2/opencv.hpp>

void AsciiAnimation(int scale, bool whiteBackground) {
    std::string ascii{ "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,\"^`'." };
    const size_t asciiSize = ascii.size();
    if (whiteBackground) {
        std::reverse(ascii.begin(), ascii.end());
    }
    cv::VideoCapture video{};
    video.open("../testForOpencv/data/fa19e0039ef855dfa8dacdef531e7528.mp4");
    if (!video.isOpened()) {
        return;
    }
    cv::Mat frame{};
    while (1) {

        video >> frame;

        if (frame.empty()) {
            return;
        }
        cv::waitKey(20);
        cvtColor(frame, frame, CV_BGR2GRAY);
        resize(frame, frame, cv::Size(frame.cols / scale, frame.rows / (2 * scale)), 0, 0, cv::INTER_LINEAR);
        for (int i = 0; i < frame.rows; ++i) {
            for (int j = 0; j < frame.cols; ++j) {
                uchar data = frame.at<uchar>(i, j);
                size_t idx = asciiSize - ((size_t)(data)* asciiSize / 255);
                printf("%c", ascii[idx]);
            }
            printf("\n");
        }
    }
}

int main() {
    AsciiAnimation(5, false);
    return 0;
}
